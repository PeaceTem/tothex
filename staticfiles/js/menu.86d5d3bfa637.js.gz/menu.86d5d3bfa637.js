const menu = document.getElementsById('menu-icon');
const back = document.getElementsById('back');
const section = document.getElementsByTagName('section');

const hideBar = () =>{

}

const showBar = () =>{
    // menu.style.display = 'none';
    
    console.log('This is the menu page.')

}
